from django.shortcuts import render, redirect
from testapp.forms import userform
from testapp.models import usermodel
from django.http import HttpResponseRedirect
from django.urls import reverse


def index(request):
    form = userform()
    if request.method == 'POST':
        form = userform(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/data')
    else:
        form = userform()
    return render(request, 'myapp/data.html', {'form': form})

def retrieve(request):
    users = usermodel.objects.all()
    return render(request, 'myapp/retrieve.html', {'users': users})



# Create your views here.
