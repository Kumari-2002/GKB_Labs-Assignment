from django import forms
from testapp.models import usermodel
class userform(forms.ModelForm):
    class Meta:
        model = usermodel
        fields = ['name','email','age','dob']